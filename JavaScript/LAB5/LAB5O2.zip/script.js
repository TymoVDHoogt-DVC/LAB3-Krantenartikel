let gegevensContainer = document.getElementById("gegevens")

fetch("opdracht2_bijlage.json")
    .then(response => response.json())
    .then(data => {
        console.log(data)

        for (let i = 0; i < data.length; i++) {
            gegevensContainer.textContent += "Naam: " + data[i].voornaam + " " + data[i].achternaam + "\n" + "Nationaliteit: " + data[i].nationaliteit + "\n" + "Leeftijd: " + data[i].leeftijd + "\n" + "Gewicht: " + data[i].gewicht + "\n" + "\n"
        }
})
