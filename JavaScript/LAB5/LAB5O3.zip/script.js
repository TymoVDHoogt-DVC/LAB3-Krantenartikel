let gegevensContainer = document.getElementById("gegevens")
let leeftijdInput = document.getElementById("leeftijd")
let filterKnop = document.getElementById("filterKnop")

let personen = []

fetch("opdracht2_bijlage.json")
    .then(response => response.json())
    .then(data => {
        personen = data

        for (let i = 0; i < personen.length; i++) {
            gegevensContainer.textContent +=
                "Naam: " + personen[i].voornaam + " " + personen[i].achternaam + "\n" +
                "Nationaliteit: " + personen[i].nationaliteit + "\n" +
                "Leeftijd: " + personen[i].leeftijd + "\n" +
                "Gewicht: " + personen[i].gewicht + "\n\n"
        }
    })

filterKnop.addEventListener("click", function() {
    let ingevuldeLeeftijd = Number(leeftijdInput.value)

    gegevensContainer.textContent = ""

    for (let i = 0; i < personen.length; i++) {
        if (personen[i].leeftijd > ingevuldeLeeftijd) {
            gegevensContainer.textContent +=
                "Naam: " + personen[i].voornaam + " " + personen[i].achternaam + "\n" +
                "Nationaliteit: " + personen[i].nationaliteit + "\n" +
                "Leeftijd: " + personen[i].leeftijd + "\n" +
                "Gewicht: " + personen[i].gewicht + "\n\n"
        }
    }
})