let gegevensContainer = document.getElementById("gegevens")

fetch("opdracht1_bijlage.json")
    .then(response => response.json())
    .then(data => {
        gegevensContainer.textContent = "Naam: " + data.voornaam + " " + data.achternaam + "\n" + "Nationaliteit: " + data.nationaliteit + "\n" + "Leeftijd: " + data.leeftijd + "\n" + "Gewicht: " + data.gewicht
    })


